package model;

import java.util.ArrayList;

/**
 * @author Siyuan He
 * @create 2021-10-21 9:36
 */
public class School {
    //    添加学院课程列表，学院名，学生列表
    ArrayList<Course> schoolCourseList;
    String schoolName;
    ArrayList<Graduate> schoolGraduates;

    public School() {
    }

    public School(String schoolName) {
        this.schoolName = schoolName;
        schoolCourseList = new ArrayList<>();
        schoolGraduates = new ArrayList<>();
    }

    //添加这个学院的全部学生
    public void addSchoolGraduates(Graduate... graduate) {

    }

    //添加这个学院的全部课程
    public void addSchoolCourseList(Course... course) {

    }

    public ArrayList<Course> getSchoolCourseList() {
        return schoolCourseList;
    }

    public void setSchoolCourseList(ArrayList<Course> schoolCourseList) {
        this.schoolCourseList = schoolCourseList;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public ArrayList<Graduate> getSchoolGraduates() {
        return schoolGraduates;
    }

    public void setSchoolGraduates(ArrayList<Graduate> schoolGraduates) {
        this.schoolGraduates = schoolGraduates;
    }

}
