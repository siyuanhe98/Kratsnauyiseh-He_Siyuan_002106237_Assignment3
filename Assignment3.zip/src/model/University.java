package model;

import java.util.ArrayList;

/**
 * @author Siyuan He
 * @create 2021-10-21 9:31
 */
public class University {
    //    添加大学课程列表，大学名，学院列表，学生列表
    String universityName;
    ArrayList<School> schoolList;
    ArrayList<Course> allCourseList;
    ArrayList<Graduate> allGraduates;


    public University(String universityName) {
        this.universityName = universityName;
        schoolList = new ArrayList<>();
        allCourseList = new ArrayList<>();
        allGraduates = new ArrayList<>();
    }

    //添加这个大学的全部学生（所有学院中schoolGraduates之和即为学院全部学生，不需要传入形参）
    public void addAllGraduates() {

    }

    //添加这个大学的全部课程（所有学院中schoolCourseList之和即为学院全部课程，不需要传入形参）
    public void addAllCourseList() {

    }

    //添加这个大学的全部学院
    public void addSchoolList(School... school) {

    }

    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public ArrayList<School> getSchoolList() {
        return schoolList;
    }

    public void setSchoolList(ArrayList<School> schoolList) {
        this.schoolList = schoolList;
    }

    public ArrayList<Course> getAllCourseList() {
        return allCourseList;
    }

    public void setAllCourseList(ArrayList<Course> allCourseList) {
        this.allCourseList = allCourseList;
    }

    public ArrayList<Graduate> getAllGraduates() {
        return allGraduates;
    }

    public void setAllGraduates(ArrayList<Graduate> allGraduates) {
        this.allGraduates = allGraduates;
    }
}
