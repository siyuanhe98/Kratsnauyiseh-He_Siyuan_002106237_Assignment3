package model;

/**
 * @author Siyuan He
 * @create 2021-10-21 10:13
 */
public class Job {
    //    职位名称，级别（用1，2，3，4，5,6等代表不同级别，也算是promotion了），薪资
    private String jobName;
    private int jobLevel;
    private double jobSalary;

    public Job() {
    }

    public Job(String jobName, int jobLevel, double jobSalary) {
        this.jobName = jobName;
        this.jobLevel = jobLevel;
        this.jobSalary = jobSalary;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public int getJobLevel() {
        return jobLevel;
    }

    public void setJobLevel(int jobLevel) {
        this.jobLevel = jobLevel;
    }

    public double getJobSalary() {
        return jobSalary;
    }

    public void setJobSalary(double jobSalary) {
        this.jobSalary = jobSalary;
    }
}
