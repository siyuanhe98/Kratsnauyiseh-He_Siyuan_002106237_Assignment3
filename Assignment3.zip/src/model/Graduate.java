package model;

import sun.reflect.generics.tree.Tree;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author Siyuan He
 * @create 2021-10-21 9:38
 */
public class Graduate {
    /*    添加学生姓名，所属学院，所学课程列表，
        职业发展（Map中key值储存int，代表1，2，3，4，5的年份，value值储存job类型，这样key-value对就一一对应了每个年份和职业）*/
    String graduateName;
    School graduateSchool;
    ArrayList<Course> graduateCourseList;
    Map<Integer, Job> careerPath;

    public Graduate(String graduateName, School graduateSchool) {
        this.graduateName = graduateName;
        this.graduateSchool = graduateSchool;
        graduateCourseList = new ArrayList<>();
        careerPath = new TreeMap<>();
    }

    //注册课程
    public void registerCourse(Course... course) {

    }

    //删除课程
    public void deleteCourse(Course... course) {

    }

    //可变形参用job类型数组，然后put(1,job[1]...便可实现)
    public void editCareerPath(Job... job) {

    }

    //相当于重写了toString方法，打印学生各信息
    public void showGarduateInfo() {

    }

    public ArrayList<Course> getGraduateCourseList() {
        return graduateCourseList;
    }

    public void setGraduateCourseList(ArrayList<Course> graduateCourseList) {
        this.graduateCourseList = graduateCourseList;
    }

    public Map<Integer, Job> getCareerPath() {
        return careerPath;
    }

    public void setCareerPath(Map<Integer, Job> careerPath) {
        this.careerPath = careerPath;
    }

    public String getGraduateName() {
        return graduateName;
    }

    public void setGraduateName(String graduateName) {
        this.graduateName = graduateName;
    }

    public School getGraduateSchool() {
        return graduateSchool;
    }

    public void setGraduateSchool(School graduateSchool) {
        this.graduateSchool = graduateSchool;
    }

}
