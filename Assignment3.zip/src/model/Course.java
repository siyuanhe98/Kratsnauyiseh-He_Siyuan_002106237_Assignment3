package model;

/**
 * @author Siyuan He
 * @create 2021-10-21 9:37
 */
public class Course {
    private String courseName;

    public Course() {
    }

    public Course(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
