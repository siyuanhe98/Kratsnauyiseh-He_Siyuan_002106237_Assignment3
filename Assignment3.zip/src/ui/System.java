package ui;

import model.Course;
import model.Graduate;
import model.School;
import model.University;

import java.util.ArrayList;

/**
 * @author Siyuan He
 * @create 2021-10-21 11:28
 */
public class System {
    //利用comparator接口对ArrayList<Graduate> graduates中Map中value值job的level属性从高到低排序，
    // int year指示Map中key值int，即指定年份
    public ArrayList<Graduate> rankGraduatesByLevel(ArrayList<Graduate> graduates, int year) {
        return null;
    }

    //利用comparator接口对ArrayList<Graduate> graduates中Map中value值job的salary属性从高到低排序，
    // int year指示Map中key值int，即指定年份
    public ArrayList<Graduate> rankGraduatesBySalary(ArrayList<Graduate> graduates, int year) {
        return null;
    }

    //遍历指定school中ArrayList<Graduate> schoolGraduates的ArrayList<Course> graduateCourseList，找到该学院毕业生重复次数最多的课
    public ArrayList<Course> mostselectedCourse(School school) {
        return null;
    }

    //利用comparator接口对指定school中的ArrayList<Graduate> schoolGraduates中Map中value值job的salary属性从高到低排序，
    //并将前10%的schoolGraduates返回一个新数组X
    //遍历X的ArrayList<Course> graduateCourseList，找到该学院被工资前10%毕业生选择重复次数最多的课
    public ArrayList<Course> mostselectedCoursebyGreatGraduates(School school) {
        return null;
    }

    //求出指定year，指定学院中ArrayList<Graduate> schoolGraduates中Map中value值job的level属性的平均值
    public int getSchoolAverageLevel(School school, int year) {
        return 0;
    }

    //排序各学院指定年份平均级别
    public ArrayList<School> rankSchoolsAverageLevel(int year) {
        return null;
    }

    //求出指定year，指定学院中ArrayList<Graduate> schoolGraduates中Map中value值job的salary属性的平均值
    public double getSchoolAverageSalary(School school, int year) {
        return 0;
    }

    //排序各学院指定年份平均收入
    public ArrayList<School> rankSchoolsAverageSalary(int year) {
        return null;
    }

    //打印该大学所有学生信息
    public void showAllGraduatesInfo() {

    }

    //打印该大学所有课程信息
    public void showAllCoursesInfo() {

    }

    //打印该大学所有学院信息
    public void showAllSchoolsInfo() {

    }
}
